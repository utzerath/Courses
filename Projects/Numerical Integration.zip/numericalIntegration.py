import numpy as np
import matplotlib.pyplot as plt

# Define the functions for numerical integration
def f1(x):
    return np.sin(x) + 1

def f2(x):
    return 3 * x + 2 * x ** 2

def f3(x):
    return np.log(x)

def f4(x):
    return x ** 2 - x ** 3

# Define the Riemann sum function
def riemann_sum(func, a, b, n, method):
    dx = (b - a) / n
    x = np.linspace(a, b, n + 1)

    if method == 'left':
        x = x[:-1]
    elif method == 'right':
        x = x[1:]
    elif method == 'mid':
        x = (x[:-1] + x[1:]) / 2
    else:
        raise ValueError("Method must be 'left', 'right', or 'mid'.")

    return np.sum(func(x) * dx)


# Part a - Plot f(x) = sin(x) + 1 with rectangles for the Riemann sum
def plot_riemann_sum(func, a, b, n, method):
    dx = (b - a) / n
    x = np.linspace(a, b, n + 1)
    y = func(x)

    if method == 'left':
        x_rect = x[:-1]
    elif method == 'right':
        x_rect = x[1:]
    elif method == 'mid':
        x_rect = (x[:-1] + x[1:]) / 2
    else:
        raise ValueError("Method must be 'left', 'right', or 'mid'.")

    y_rect = func(x_rect)

    plt.figure(figsize=(12, 7))
    plt.plot(x, y, 'b', linewidth=2)
    plt.bar(x_rect, y_rect, width=dx, alpha=0.3, align='edge', edgecolor='b')
    plt.title(f'Riemann Sum of f(x) = sin(x) + 1 using {n} rectangles')
    plt.show()



# Calculate the Riemann sum for the given functions and intervals
riemann_sum_f1 = riemann_sum(f1, -np.pi, np.pi, 4, 'mid')
# Part a - Graph of sin(x) + 1 over [-π, π] with four subintervals of equal length
plot_riemann_sum(f1, -np.pi, np.pi, 4, 'mid')

# Part b - Riemann sum formula for f(x) = 3x + 2x^2 over [0, 1]
riemann_sum_f2 = riemann_sum(f2, 0, 1, 1000, 'right')
x_values_ln = np.linspace(0, 1, 400)
y_values_ln = f2(x_values_ln)
plt.figure(figsize=(10, 5))
plt.plot(x_values_ln, y_values_ln, label='f(x) = ln(x)', color='blue')
plt.fill_between(x_values_ln, y_values_ln, color='lightblue', alpha=0.5)
plt.title('Function f(x) = 3x + 2x^2 and area under the curve')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.legend()
plt.grid(True)
plt.show()

# Part c - Riemann sum for the definite integral of ln(x) from 1 to e
riemann_sum_f3 = riemann_sum(f3, 1, np.e, 1000, 'mid')
# Plot the function f(x) = ln(x)
x_values_ln = np.linspace(1, np.e, 400)
y_values_ln = f3(x_values_ln)
plt.figure(figsize=(10, 5))
plt.plot(x_values_ln, y_values_ln, label='f(x) = ln(x)', color='blue')
plt.fill_between(x_values_ln, y_values_ln, color='lightblue', alpha=0.5)
plt.title('Function f(x) = ln(x) and area under the curve')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.legend()
plt.grid(True)
plt.show()

# Part C 2 - Riemann sum for f(x) = x^2 - x^3 over [-1, 0]
riemann_sum_f4 = riemann_sum(f4, -1, 0, 1000, 'right')
# Plot the function f(x) = x^2 - x^3
x_values_x2_x3 = np.linspace(-1, 0, 400)
y_values_x2_x3 = f4(x_values_x2_x3)
plt.figure(figsize=(10, 5))
plt.plot(x_values_x2_x3, y_values_x2_x3, label='f(x) = x^2 - x^3', color='red')
plt.fill_between(x_values_x2_x3, y_values_x2_x3, color='salmon', alpha=0.5)
plt.title('Function f(x) = x^2 - x^3 and area under the curve')
plt.xlabel('x')
plt.ylabel('f(x)')
plt.legend()
plt.grid(True)
plt.show()

# print the riemann integral
print("Numerical approximaiton of the Riemann Integral of Part 1 A) ", riemann_sum_f1)
print("Numerical approximaiton of the Riemann Integral of Part 1 B) ", riemann_sum_f2)
print("Numerical approximaiton of the Riemann Integral of Part 1 C) ", riemann_sum_f3)
print("Numerical approximaiton of the Riemann Integral of Part 1 C2) ",riemann_sum_f4)


#----------------------------------------------------------------------------------------------


def R(t):

    return np.piecewise(t, [t < 10, t < 20, t >= 20], [lambda t: 250, lambda t: 380, lambda t: 430])

# Used Riemann sum function from Part 1
# Calculate the total amount of data downloaded using the right endpoint method
total_data_downloaded_megabits = riemann_sum(R, 0, 30, 30, 'right')

# Convert the total megabits to megabytes (1 megabit = 0.125 megabytes)
total_data_downloaded_megabytes = total_data_downloaded_megabits * 0.125

# Output the result
print(f"Total data downloaded over 30 minutes is approximately {total_data_downloaded_megabytes:.2f} Megabytes.")

# Plotting for visualization
t_values = np.linspace(0, 30, 300)
R_values = R(t_values)

plt.figure(figsize=(12, 6))
plt.plot(t_values, R_values, label='Download Rate R(t)', color='blue')
plt.fill_between(t_values, R_values, color='lightblue', alpha=0.5)
plt.title('Download Rate R(t) Over Time')
plt.xlabel('Time (minutes)')
plt.ylabel('Rate (Mbps)')
plt.legend()
plt.grid(True)
plt.show()
