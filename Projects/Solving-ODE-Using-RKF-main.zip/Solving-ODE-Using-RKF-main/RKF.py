#Jack Utzerath
#Packages: Numpy, matplotlib, scipy
#using 4th order RKF method to solve ODE

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint

# Define the ODE function: f(x, y) = -y + ln(x)
def f(y, x):
    return -y + np.log(x)

# Initial conditions and parameters
x0 = 2.0
y0 = 1.0
x_target = 300
x_values = np.linspace(x0, x_target, 1000)  # Create evenly spaced x values
y_values = odeint(f, y0, x_values)[:, 0]

# Create a matplotlib graph of the solution
plt.figure(figsize=(10, 6))
plt.plot(x_values, y_values, '--', label="ODE Solution (odeint)")
plt.xlabel("x")
plt.ylabel("y")
plt.title("ODE Solving")
plt.grid(True)


import numpy as np
import matplotlib.pyplot as plt

#Reading ODE as an input
def dydx(x, y):
    return -y + np.log(x)

#solving the ode using the runge kutta fehlburg method
def rungeKutta(x0, y0, x, h):
    #initialize array
    x_values = []
    y_values = []

    #set up n and y
    n = (int)((x - x0) / h)
    y = y0

    #for loop for rkf 
    for i in range(1, n + 1):

        #displays x and y to console 
        print(f"X(n) =  {round(x0, 5)}    Y(n) = {round(y, 5)} ")
        k1 = h * dydx(x0, y)
        k2 = h * dydx(x0 + 0.5 * h, y + 0.5 * k1)
        k3 = h * dydx(x0 + 0.5 * h, y + 0.5 * k2)
        k4 = h * dydx(x0 + h, y + k3)

        #update y and x
        y = y + (1.0 / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        x0 = x0 + h

        #add variables to array
        x_values.append(x0)
        y_values.append(y)

    #return values
    return x_values, y_values

# Driver method
x0 = 2
y0 = 1
x = 1000
h = 0.3

x_values, y_values = rungeKutta(x0, y0, 300, h)

# Create a matplotlib graph with a dotted line up to x=300
plt.plot(x_values, y_values, '--', label="Runge-Kutta Solution (Dotted Line)", linestyle='--', color = 'orange')
plt.legend()
plt.show()

