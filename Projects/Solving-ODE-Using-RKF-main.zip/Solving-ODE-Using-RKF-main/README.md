# Solving-ODE-Using-RKF

#download python file and use ide or linux to run program
#Packages Used: Matplotlib, numpy, and scipy

#For the implementation in Code, I used three packages. Numpy, matplotlib, and scipy. I first used odeint to solve the ODE. This #is a function in scipy that is used to calculate the next point for differentiable equations. Then I used the runge kutta #method to solve the ODE. I stored the variables in an array and used a for loop to update the x and y values. In the for loop, #I also printed the values to the console. With these two methods, I was able to use matplotlib to plot these functions and #compare them both on the same graph. 
