#ifndef TEST_H
#define TEST_H

#include <iostream>

using namespace std;

class Test 
{
private:
	int num1;
public:
	int operator()(int num1);
};

#endif TEST_H