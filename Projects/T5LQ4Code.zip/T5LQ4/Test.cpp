#include "Test.h"

//operator function that takes in a number
int Test::operator()(int num1)
{
    //adds 7 to the input value and returns result
    int result = num1 + 7;
    return result;
}
