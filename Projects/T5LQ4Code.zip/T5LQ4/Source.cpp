//Ian Fletcher
//This is my own code with help from docs.microsoft.com on c++

#include <iostream>
#include "Test.h"

using namespace std;

int main()
{
	//creates Test object t
	Test t;
	//creates int num that equals 10
	int num = 10;
	//pases num into the operator function
	int result = t(num);
	//prints out result
	cout << result;
	return 0;
}