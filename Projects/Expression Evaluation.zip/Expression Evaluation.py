#Jack Utzerath

# Function to determine the precedence of operators.
def precedence(op):
    if op == '+' or op == '-':
        return 1  # Lowest precedence
    if op == '*' or op == '/':
        return 2  # Higher precedence than + and -
    if op == '^':
        return 3  # Highest precedence for exponentiation
    return 0  # Default case for invalid operators

# Function to apply an operation to two numbers.
def apply_op(a, b, op):
    if op == '+': return a + b  # Addition
    if op == '-': return a - b  # Subtraction
    if op == '*': return a * b  # Multiplication
    if op == '/': return a / b  # Division
    if op == '^': return pow(a, b)  # Exponentiation

# Function to evaluate an expression given as a string with tokens.
def evaluate(tokens):
    values = []  # Stack to hold the numbers
    ops = []  # Stack to hold the operators
    i = 0  # Iterator for the string

    # Iterate over each character in the string
    while i < len(tokens):
        # Skip whitespaces
        if tokens[i] == ' ':
            i += 1
            continue
        
        # If the token is an opening bracket, push it to ops stack
        elif tokens[i] == '(':
            ops.append(tokens[i])
        
        # If the token is a digit, parse the number and push to values stack
        elif tokens[i].isdigit():
            val = 0
            # There might be more than one digit in the number
            while i < len(tokens) and tokens[i].isdigit():
                val = (val * 10) + int(tokens[i])
                i += 1
            values.append(val)
            
            # Decrement i to avoid skipping a character
            i -= 1
        
        # If the token is a closing bracket, solve the expression within the brackets
        elif tokens[i] == ')':
            while ops and ops[-1] != '(':
                val2 = values.pop()
                val1 = values.pop()
                op = ops.pop()
                values.append(apply_op(val1, val2, op))
            ops.pop()  # Remove the opening bracket
        
        # If the token is an operator, process it according to precedence
        else:
            # Apply operator at the top of the ops stack if it has higher or same precedence
            while ops and precedence(ops[-1]) >= precedence(tokens[i]):
                val2 = values.pop()
                val1 = values.pop()
                op = ops.pop()
                values.append(apply_op(val1, val2, op))
            # Push the current operator to the ops stack
            ops.append(tokens[i])
        i += 1

    # After the whole expression is parsed, apply remaining operations
    while ops:
        val2 = values.pop()
        val1 = values.pop()
        op = ops.pop()
        values.append(apply_op(val1, val2, op))

    # The top of the values stack contains the result, return it
    return values[0]

# The test cases demonstrate the functionality of the evaluate function
print(evaluate("10 + 2 * 6"))             # Should output 22
print(evaluate("100 * 2 + 12"))           # Should output 212
print(evaluate("100 * ( 2 + 12 )"))       # Should output 1400
print(evaluate("100 * ( 2 + 12 ) / 14"))  # Should output 100
print(evaluate("3 ^ 2 + 1"))              # Should output 10
