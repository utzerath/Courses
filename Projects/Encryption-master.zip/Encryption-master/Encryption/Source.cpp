// Jack Utzerath
// CST-210
// Encryption
// 1/12/22
// This is my own work

#include <iostream>
#include <string>
using namespace std;

//Initialize methods
int key();
void encrypt(int key);

//Driver Method
int main() 
{
	
	encrypt(key());
	
	return 0;
}

//Key Method
int key()
{
	int key;

	//Ask user to enter a number and store it
	cout << "Enter the key: " << endl;
	cin >> key;

	// If number is higher than 26 -> modulus 26
	if (key > 26)
	{
		key %= 26;
	}
	
	//cout << key << endl;

	//Return the Key
	return key;

}

//Encrypted Coded message
void encrypt(int key)
{
	//Array of alphabet
	char alph[] = "abcdefghijklmnopqrstuvwxyz";
	// Gets size of the array
	int lengthOfArray = sizeof(alph);

	string message, message2;

	//Ask user to enter a sentence
	cout << "Enter words to encrypt, enter QUIT to quit: " << endl;
	
	
	//While it has next word
	while (cin >> message)
	{
		//Reset Message2 at beginning of loop
		message2 = "";

		//Nest for loop to compare chars in the message and alphabet
		for (int j = 0; j < message.length(); j++)
		{
			for (int i = 0; i < lengthOfArray; i++)
			{
				//If chars of message and alphabet are equal
				if (alph[i] == message.at(j))
				{
					//Add the key to i 
					//this will output new letter
					int encrypt = i + key;

					//if encrypt is less than 26
					if (encrypt < 26)
					{

						message2 += alph[encrypt];
					}
					//if encrypt is greater than 26
					else
					{
						//Make sure it pulls a letter from to the alphabet
						encrypt -=  26;
						
						message2 += alph[encrypt];
					}

				}

			}
			
		}

		//This print statment breaks my code for some reason
		//printf("%10s %10s\n", message.c_str(), message2.c_str());

		//Output the message
		cout << "\t" + message + "\t" + message2 << endl;
		
	}

}