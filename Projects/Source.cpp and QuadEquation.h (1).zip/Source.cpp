/*
* Jack Utzerath
* CST-210
* Quadratic Equation
* 2/1/21
*/
#include <iostream>
#include "QuadraticEquation.h"

using namespace std;

int main() 
{

	QuadraticEquation eq(3, 13, -10);
	QuadraticEquation eq2(3, -12, -10);

	QuadraticEquation sum = eq + eq2;
	QuadraticEquation difference = eq - eq2;

	cout << "(" << eq << ") - (" << eq2 << ") = (" << difference << ")";


	return 0;
}

