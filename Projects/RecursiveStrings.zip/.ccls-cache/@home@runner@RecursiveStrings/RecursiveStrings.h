/*
* Jack Utzerath
* This is my work
* October 2022
*/

using namespace std;
#include <string>
#include <iostream>

#ifndef RECURSIVESTRING_H
#define RECURSIVESTRING_H

class RecursiveString 
{

public:
	RecursiveString()
	{

	}
	bool isSlop(string a)
	{

	}
	bool isSlap(string a, int count)
	{
		/*
		int length = a.length();
		
		if (count == 0)
		{
			if (a[0] != 'A')
			{
				cout << "False 0";
				return false;
			}
			if (length = 2 && a[1] == 'H')
			{
				return true;
			}
		}
		
		
		if (a[0] == 'A')
		{
			if (a[1] == 'B' || a[1] == 'H')
			{
				
			}
			else if (isSlip(a.substr(1, length), 0) == true)
			{

			}
			else
			{
				return false;
			}
		}
		
		if (a[0] == 'B' || a[0] == 'H')
		{
			if (a[0] == 'C' || a[0] == 'A')
			{

			}
			else
			{
				return false;
			}
		}

		
		
		if (a[0] == 'C')
		{
				return true;
		}

		*/
		return true;

		//isSlap(a.substr(1, length), 1);
		
	}

	bool isSlip(string a, int count)
	{
		/*if D or E then a + 1 must be an F
		* if F then a + 1 can be F or D or E or G
		* if G then a + 1 must end the slip
		* return substring - 1
		* go until no substring
		*/

		//cout << count << a[0] << "Hey";
		
		if (count == 0)
		{
			if (a[0] == 'D' || a[0] == 'E') {}
			else
			{
				cout << "False 0";
				return false;
			}
			
		}
		
		
		int length = a.length();

		
		if (a[0] == 'E' || a[0] == 'D' || a[0] == 'F' || a[0] == 'G') {}

		else
		{
			cout << "False 1";
			return false;
		}
		if (a[0] == 'E' || a[0] == 'D')
		{
			if (a[1] != 'F')
			{
				cout << "False 2";
				return false;
			}
		}
		if (a[0] == 'F')
		{
			//A + 1 can be F or D or E or G
				if (a[1] == 'E' || a[1] == 'D' || a[1] == 'F' || a[1] == 'G') {}

				else
				{
					cout << "False 3";
					return false;
				}
				
		}

		if (a[0] == 'G')
		{
			return true;
		}

		

		return isSlip(a.substr(1, length), 1);
		

	}

};

#endif