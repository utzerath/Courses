/*
* Jack Utzerath
* This is my work
* October 2022
*/

using namespace std;
#include <string>
#include <iostream>
#include <fstream>
#include "RecursiveString.h"

int main()
{
	string foo;

	ifstream fin("slip.in");
  
	if (!fin) {
		  cout << "File not found\n";
  		exit(2);
	}

	//fin >> foo;
	

	RecursiveString rStr;

	while (fin >> foo)
	{
  	cout << foo << endl;
  	bool output2 = rStr.isSlip(foo, 0);
    //bool output2 = rStr.isSlap(foo);
  	//bool output2 = rStr.isSlop(foo, 1);

  	cout << output2 << endl;
	}
	


	return 0;
};