/*
* Jack Utzerath
* This is my work
* October 2022
*/

using namespace std;
#include <string>
#include <iostream>

#ifndef RECURSIVESTRING_H
#define RECURSIVESTRING_H

class RecursiveString 
{

public:
	RecursiveString()
	{

	}
	bool isSlop(string a, int count)
	{
  
    int length = a.length();
    
    //cout << isSlap(a.substr(0, count));
    if (isSlap(a.substr(0,count)))
    {
      //cout << "Here";
        if (isSlip(a.substr(count, length), 0))
        {
          //cout << "true lol";
          return true;
          
          
        }
        else
        {
          return false;
        }
    }
    else
    {
      //cout << "Nerd" << isSlop(a,count++);
      isSlop(a,count + 1);
      

    }
   
    return true;
    
    
	}
	bool isSlap(string a)
	{
    int length = a.length();
    //cout << "First Letter" << a[0] << endl;
    //cout << "Last Letter" << a[length-1] << endl;
    
		
		

		if (a[0] != 'A')
		{
			//cout << "False 0";
			return false;
		}
		if (length == 2 &&  a[0] == 'A' && a[1] == 'H')
		{
			return true;
		}
		
    
    
    if(a[0] == 'A')
    { 
      if(a[1] == 'B' && a[length - 1] == 'C')
      {
        //cout << "Here" << endl << isSlap(a.substr(2,3));
        return isSlap(a.substr(2,length - 3));
      }
      
      else if(isSlip(a.substr(1,length - 2), 0) && a[length - 1]  == 'C')
      {
        
        return true;
      }
      
      else
      {
        return false;
      }
      
    }
    
		return false;
		
    cout << "Shouldn't be here";
	
		
	}

	bool isSlip(string a, int count)
	{
		/*if D or E then a + 1 must be an F
		* if F then a + 1 can be F or D or E or G
		* if G then a + 1 must end the slip
		* return substring - 1
		* go until no substring
		*/

		//cout << count << a[0] << "Hey";
		
		if (count == 0)
		{
			if (a[0] == 'D' || a[0] == 'E') {}
			else
			{
				//cout << "False 0";
				return false;
			}
			
		}
		
		
		int length = a.length();

		
		if (a[0] == 'E' || a[0] == 'D' || a[0] == 'F' || a[0] == 'G') {}

		else
		{
			//cout << "False 1";
			return false;
		}
		if (a[0] == 'E' || a[0] == 'D')
		{
			if (a[1] != 'F')
			{
				//cout << "False 2";
				return false;
			}
		}
		if (a[0] == 'F')
		{
      if (a[1] == 'F')
      {
        int i = 1;
        while (a[i] == 'F')
          {
            i++;
          }
        return isSlip(a.substr(i, length), 1);
      }
			//A + 1 can be F or D or E or G
			else if (a[1] == 'E' || a[1] == 'D' || a[1] == 'G') {}
        

				else
				{
					//cout << "False 3";
					return false;
				}
				
		}

		if (a[0] == 'G')
		{
			return true;
		}

		

		return isSlip(a.substr(1, length), 1);
		

	}

};

#endif