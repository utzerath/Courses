/*
* Jack Utzerath
* CST-201
* Array Sorting
* 9/8/22
*/



#include <fstream>
#include <string>
#include <iostream>

//Binary Seach mehthod
int binarySearch(std::string myArray[], std::string stringInArr, int n)
{
	//get lower and upper
	int lower = 0;
	int upper = n - 1;

	while (lower <= upper)
	{
		//get the middle of the array
		int mid = lower + (upper - lower) / 2;

		//if it is in the middle then check = 0
		if (stringInArr == (myArray[mid]))
		{
			return mid - 1;
		}

		//if on the right side then delete the left side
		if (stringInArr > (myArray[mid]))
		{
			lower = mid + 1;
		}
		//if on the left side then we are going to delete the right side
		else
		{
			upper = mid - 1;
		}
	}
	return -1;
}

int main()
{
	//Initialize Variable
	int count = 0;
	
	std::string fillArr;
	std::string myArray [10000] ;

	//Read from a file
	std::ifstream input;
	//open text file
	input.open("text.txt");

	
	std::cout << "Array: " << std::endl;
	while (input)
	{
		//fill array with text from file
		input >> myArray[count];
		
		//print out the array
		std::cout << myArray[count] << " ";
		
		count++;
	}

	std::cout << std::endl;

	//insertion sort 

	int i, j;
	std::string str;

	std::cout << "Sorted Array: " << std::endl;
	for (i = 1; i < count; i++)
	{
		//fill temp string with myArray
		str = myArray[i];
		//set j
		j = i - 1;

		//compare the index and i
		//this for loop trys to find the correct position to insert the given index
		while (j >= 0 && myArray[j] > str)
		{

			myArray[j + 1] = myArray[j];

			//move index back one place to compare the previous element with i
			j = j - 1;
		}
		//insert the element at the right place
		myArray[j + 1] = str;
		
	}
	
	//print out new array
	for (i = 0; i < count; i++)
	{
		std::cout << myArray[i] << " ";
		
	}
	std::cout << std::endl << std::endl;
	
	std::string word;
	bool userHadEnough = false;

	//while loop for the binary search
	while (!userHadEnough)
	{
		std::cout << "What word would you like to search for (DONE to End Search): ";
		std::cin >> word;

		//stop while loop
		if (word == "DONE")
		{
			userHadEnough = true;
		}

		//use binary search method
		int ans = binarySearch(myArray, word, 13);

		//print out if search is in the array or not
		if (ans == -1)
		{
			std::cout << "This word is not in the array" << std::endl;
		}
		else
			std::cout << word << " is in the " << ans << " index of the array" << std::endl;

	}

	
	
	
	return 0;
}
