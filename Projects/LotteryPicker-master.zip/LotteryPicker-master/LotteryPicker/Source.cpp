// Jack Utzerath
// CST-210
// Lottery Picker 
// 1/12/22
// This is my own work


#include <vector>
#include <iostream>
#include <algorithm>


using namespace std;

void whileLoop();
vector<int> getNumbers();
void setPowerball(vector<int>& numbers);
void showNumbers(const vector<int>& v);

int main() {

	//Cleaned up main method
	whileLoop();

	return 0;

}

vector<int> getNumbers() {
	//Intializing Vector
	vector<int> numbers;


	//For loop for adding elements to Vector
	for (int i = 0; i < 4; i++)
	{
		int n = rand() % 69 + 1;
		if (find(numbers.begin(), numbers.end(), n) == numbers.end())
		{
			numbers.push_back(n);
		}
	}

	

	//Sort method will put elements in ascending order
	sort(numbers.begin(), numbers.end());

	return numbers;


}

void setPowerball(vector<int>& numbers) {
	//Add PB number
	numbers.push_back(rand() % 30 + 1);

}

void showNumbers(const vector<int>& v) {

	//For loop to display the numbers
	for (int i = 0; i < v.size(); i++) 
	{
		if (v[i] < 10)
		{
			cout << v[i] << "  ";
		}

		else { cout << v[i] << " ";}
		//Display PB
		if (i == 3)
		{
			cout << "PB ";
		}
	}

}

void checkVector(vector<int>& v)
{
	if (v.size() != 5)
	{
		v.push_back(rand() % 30 + 1);
	}
}

void whileLoop() {
	//Initalize variables
	bool ok = true;
	char again;
	srand(time(NULL));


	while (ok)
	{
		//Ask user for amount of numbers
		int lotteryNum;
		cout << "How many lottery numbers would you like to see: " << endl;
		//Get input
		cin >> lotteryNum;

		//for loop that we use other methods in
		for (int j = 0; j < lotteryNum; j++)
		{
			//Inialize vector
			vector<int> numbers = getNumbers();
			setPowerball(numbers);
			checkVector(numbers);
			showNumbers(numbers);
			cout << endl;
		}
		//Ask user if the want the loop to run again or not
		cout << "Would you like to generate more Lottery Numbers? (Y or N)" << endl;

		//End loop
		cin >> again;
		if (again == 'N')
		{
			ok = false;
		}
	}
}