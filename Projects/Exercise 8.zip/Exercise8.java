/*
 * Jack Utzerath
 * CST-105 (9am)
 * Exercise 8
 * Dec 5, 2021
 * This is my work
 */


package playingCard;

import java.util.ArrayList;

public class Exercise8 
{
	public static void main(String[] args)
	{
		// Initialize the Class
		PlayingCard playingCard = new PlayingCard();
		
		
		// Envoking this method will create the Array List of 52 cards and fill the deck automatically
		ArrayList<PlayingCard> deckOfCards = playingCard.fillDeck();
		
		// Create two random integers
		int randomNumber = (int) (Math.random() * (52 - 1) + 1);
		int randomNumber2 = (int) (Math.random() * (52 - 1) + 1);
		
		// Get random card1 and random card2 while envoking the toString method
		String card1 = (deckOfCards.get(randomNumber)).toString();
		String card2 =  (deckOfCards.get(randomNumber2)).toString();
		
		
		//If else statement to find if they match or not
		if (playingCard.isMatch(card1, card2))
		{
			System.out.print(card1 + " and " + card2 + " match");
		}
		else
		{
			System.out.print(card1 + " and " + card2 + " don't match");
		}
		
		
	
		
	}
}
