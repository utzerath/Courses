/*
 * Jack Utzerath
 * CST-105 (9am)
 * Exercise 8
 * Dec 5, 2021
 * This is my work
 */




package playingCard;

import java.util.ArrayList;

public class PlayingCard 
{
	
	//Initializing Attributes (Private)
	
	private int value;
	private char suit;
	
//----------------------------------------------
	//Constructor to Initialize the Values
	
	public PlayingCard()
	{
		this.value = 0;
		this.suit = 'N';
		
	}

//----------------------------------------------
	// Create Constructor
	
	public PlayingCard( int value, char suit)
	{
		this.value = value;
		this.suit = suit;
	}
	
//----------------------------------------------
	//Generate getters and setters 
	
	public char getSuit() 
	{
		return suit;
	}


	public void setSuit(char suit) 
	{
		this.suit = suit;
	}


	public int getValue() 
	{
		return value;
	}


	public void setValue(int value) 
	{
		this.value = value;
	}
	
//---------------------------------------------
	//To String Method 

	public String toString() 
	{
		String value = "";
		
		//Switch statement to convert 11-14 into face cards 
		
		switch(this.value)
		{
			case 11: 
				value = "J";
				break;
			case 12: 
				value = "Q";
				break;
			case 13: 
				value = "K";
				break;
			case 14:
				value = "A";
				break;
			
			default:
				//Default convert int into string
				value = String.valueOf(this.value);
				
				
		}
		//Return the String
		return   value + "," + this.getSuit() ;
	}
//---------------------------------------------------
	//Is Match Method
	
	public boolean isMatch(String Card1, String Card2)
	{
		
		
		
		
		char suit = Card1.charAt(0);
		char value = Card1.charAt(2);
		
		char suit2 = Card2.charAt(0);
		char value2 = Card2.charAt(2);
		
		
		if (suit == suit2 || value == value2)
		{
			return true;
		}
		else
		{
			return false;
		}
	
	}

//---------------------------------------------------
	
	// This method will create the Array List of 52 cards and fill the deck automatically
	
	
	public  ArrayList<PlayingCard> fillDeck()
	{
		ArrayList<PlayingCard> deckOfCards = new ArrayList<PlayingCard>();
		
		//Define variable 
		char suitType = 'N';
		
		//For loop to fill array
		for (int suit = 1; suit <= 4; suit++)
		{
			for(int value = 2; value <= 14; value++)
			{
				
				//Switch Statment to name the suit
				switch (suit)
				{
					case 1: 
						suitType = 'C';
						break;
					case 2:
						suitType = 'D';
						break;
					case 3:
						suitType = 'S';
						break;
					case 4:
						suitType = 'H';
				}
				
				
				//Fill the array at the given parameters
				deckOfCards.add(new PlayingCard(value, suitType));
				
			}
		}
		
		//Return the array
		return deckOfCards;
		
	}
}
//--------------------------------------------------
	


