/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Arena.h"
#include <time.h>
#include <iostream>
#include <fstream>



int main()
{
	srand(time(NULL));
	Arena a;

	std::cout << "Would you like to start a new game or continue?" << std::endl << "Input 1 for new game" << std::endl << "Input 2 to continue" << std::endl;
	int response;
	std::cin >> response;

	if (response == 2)
	{
		a.loadPlayerProgress();
	}
	else
	{
		a.getWeapons();
	}


	a.fight();
	return 0;
	
}