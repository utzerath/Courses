#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#ifndef BLUNT_H
#define BLUNT_H

#include "Weapon.h"
#include <string>

class Blunt: public Weapon
{
private:


public:
	Blunt(std::string, int, int);
	int attack();
	std::string getType();
};



#endif