/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work :)
*/

#include "Weapon.h"
#include <string>
#include <vector>

//each subclass has a gimic
//swords- do additional damage due to bleed
//blunt weapons- stagger oppenent on turn 4
//staff- ignore shields

Weapon::Weapon()
{
	name = "fist";
	damage = 0;
	weight = 0;

}

Weapon::Weapon(std::string name, int damage, int weight)
{
	this->name = name;
	this->damage = damage;
	this->weight = weight;

}
int Weapon::attack()
{
	return damage;
}

std::string Weapon::getType()
{
	return "";
}

void Weapon::setName(std::string name)
{
	this->name = name;
}

void Weapon::setDamage(int damage)
{
	this->damage = damage;
}
void Weapon::setWeight(int weight)
{
	this->weight = weight;
}

std::string Weapon::getName()
{
	return name;
}

int Weapon::getDamage()
{
	return damage;
}

int Weapon::getWeight()
{
	return weight;
}

