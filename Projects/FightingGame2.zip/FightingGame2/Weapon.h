#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/
#ifndef WEAPON_H
#define WEAPON_H

#include <string>
#include <vector>


//all three of the subclass have a little gimic
//swords add damage because they apply a bleed
//staff ignores shields
//blunt weapons stagger the oppenent on turn 4




class Weapon
{
protected:
	std::string name;
	int damage;
	int weight;
	std::vector <Weapon> daWeapons;

public:
	Weapon();
	Weapon(std::string, int, int);
	virtual int attack();
	virtual std::string getType();

	void setName(std::string);
	void setDamage(int);
	void setWeight(int);

	std::string getName();
	int getDamage();
	int getWeight();
	
	

	

};


#endif 