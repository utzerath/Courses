/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Swords.h"
#include <iostream>

Swords::Swords(std::string name, int damage, int weight)
{

	setName(name);
	setDamage(damage);
	setWeight(weight);
}

int Swords::attack()
{
	
	return damage + bleedProc();
	//call bleed proc
}
int Swords::bleedProc()
{
	this->bleedBuildUp += 100;

	if (bleedBuildUp > 100)
	{
		this-> bleedDamage += 3;
		return bleedDamage;
	}
	return 0;
}

std::string Swords::getType()
{
	return "Sword";
}
