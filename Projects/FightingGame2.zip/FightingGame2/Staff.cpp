/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Staff.h"

Staff::Staff(std::string name, int damage, int weight)
{

	setName(name);
	setDamage(damage);
	setWeight(weight);
}

int Staff::attack()
{
	return damage;
	//call bleed proc
}

std::string Staff::getType()
{
	return "Staff";
}