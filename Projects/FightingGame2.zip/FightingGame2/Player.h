#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include <string>
#include "Weapon.h"
#include "Store.h"

class Player
{
private:
	std::string name;
	int health;
	int healthCap;
	int numhealthPotion;
	std::string attackDirection;
	std::string blockDirection;

	Weapon* weapon1;
	Weapon* weapon2;

	int wI1;
	int wI2;



public:

	Player();
	Player(std::string name, int health, int numhealthPotion, Weapon* weapon1, Weapon* weapon2);

	int attack();
	int autoAttack();

	void block();
	void autoBlock();
	void useHealthPotion();

	std::string getName();
	int getHealth();
	std::string getAttackDirection();
	std::string getBlockDirection();
	int getNumHealthPotion();
	int getWI1();
	int getWI2();


	bool checkStaff();
	bool checkBlunt();

	void chooseWeapons();
	void autoChooseWeapons();

	void setHealth(int);
	void setName(std::string);
	void setHealthCap(int);
	void setNumHealthPotion(int);
	void setWeapon1(Weapon*);
	void setWeapon2(Weapon*);

};