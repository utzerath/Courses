/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Arena.h"
#include "Player.h"
#include <iostream>
#include <fstream>

Arena::Arena()
{
	Weapon* weapon1 = new Blunt("Fists", 1, 0);
	Weapon* weapon2 = new Shield("Starter Shield", 0, 10);
	
	daPlayers[1] = new Player("You", 100, 2, weapon1, weapon2);
	daPlayers[2] = new Player("Jutz", 200, 0, weapon1, weapon2);
}
void Arena::getWeapons()
{
	//get weapons
	daPlayers[1]->chooseWeapons();
	daPlayers[2]->autoChooseWeapons();
}
void Arena::fight()
{
	bool alive = true;
	

	int count = 0;

	bool isBluntWeapon = daPlayers[1]->checkBlunt();
	bool isBluntWeapon2 = daPlayers[2]->checkBlunt();

	while (alive)
	{
		//for stagger gimic for blunt weapons
		if (isBluntWeapon2 == true && count == 4)
		{
			std::cout << "Oppenent stagger you" << std::endl;
		}
		else
		{
			turn1();
		}
		

		if (daPlayers[2]->getHealth() <= 0)
		{
			alive = false;
		}


		//for stagger gimic for blunt weapons
		if (isBluntWeapon == true && count == 4)
		{
			std::cout << "You staggered the oppenent" << std::endl;
		}
		else
		{
			turn2();

		}

		//check alive
		if (daPlayers[1]->getHealth() <= 0)
		{
			alive = false;
		}
		
		count++;
		std::cout << "End of turn " << count << std::endl << std::endl;

		//save progress
		savePlayerProgress();

		//check alive
		if (alive == false)
		{
			std::cout << "Game Over" << std::endl;
		}

		

	}
	
}

void Arena::turn1()
{
	//Fight
	std::cout << "Fiiiight!!!" << std::endl;

	//attack
	int attack = daPlayers[1]->attack();
	std::string attDirection = daPlayers[1]->getAttackDirection();
	bool isStaff = daPlayers[1]->checkStaff();


	daPlayers[2]->autoBlock();

	//is the attack blocked?
	std::string blockDirection = daPlayers[2]->getBlockDirection();

	if (attDirection == blockDirection && isStaff == false)
	{
		attack = 0;
		std::cout << "The attack is blocked!!!" << std::endl;
	}
	else
	{
		//do damage
		std::cout << "You hit " << daPlayers[2]->getName() << std::endl;
		daPlayers[2]->setHealth(attack);
	}

	std::cout << daPlayers[2]->getName() << " has " << daPlayers[2]->getHealth() << " health" << std::endl;

}

void Arena::turn2()
{
	//Bot auto attack (random)
	int attack2 = daPlayers[2]->autoAttack();

	std::string attDirection2 = daPlayers[2]->getAttackDirection();
	bool isStaff2 = daPlayers[2]->checkStaff();

	daPlayers[1]->block();
	std::string blockDirection2 = daPlayers[1]->getBlockDirection();


	//Is the attack blocked?
	if (blockDirection2 == attDirection2 && isStaff2 == false)
	{
		attack2 = 0;
		std::cout << "The attack is blocked!!!" << std::endl;
	}
	else
	{
		//do damage
		std::cout << daPlayers[2]->getName() << " hit you" << std::endl;
		daPlayers[1]->setHealth(attack2);
	}

	//Get Health
	std::cout << "You" << " have " << daPlayers[1]->getHealth() << " health" << std::endl << std::endl;

	//Health Potion?
	std::cout << "Would you like to use a health potion: Y or N" << std::endl;
	std::string response;
	std::cin >> response;
	if (response == "Y")
	{
		daPlayers[1]->useHealthPotion();
	}

}



void Arena::savePlayerProgress()
{
	//Output file
	std::ofstream fout;
	fout.open("Player.txt");

	if (!fout.is_open())
	{
		std::cout << "File does not exist" << std::endl;
	}

	//output to file
	fout << daPlayers[1]->getName() << std::endl << daPlayers[1]->getHealth() << std::endl << daPlayers[1]->getNumHealthPotion() << std::endl
			<< daPlayers[1]->getWI1() << std::endl << daPlayers[1]->getWI2() << std::endl;
	fout << daPlayers[2]->getName() << std::endl << daPlayers[2]->getHealth() << std::endl << daPlayers[2]->getNumHealthPotion() << std::endl
		<< daPlayers[2]->getWI1() << std::endl << daPlayers[2]->getWI2() << std::endl;
	


}
//Struct for reading the input file
struct PlayerStat
{
	std::string name1;
	int health;
	int numhealthPotion;
	int weaponIndex1;
	int weaponIndex2;

};


void Arena::loadPlayerProgress()
{
	//delete dynamic data
	delete daPlayers[1];
	delete daPlayers[2];

	//Create a vetor because there is multiple character to read in
	vector<PlayerStat> files;
	PlayerStat f;

	//Open file
	std::ifstream fin;
	fin.open("Player.txt");


	if (!fin.is_open())
	{
		std::cout << "File does not exist" << std::endl;
	}
	
	//add player
	fin >> f.name1;
	fin >> f.health;
	fin >> f.numhealthPotion;
	fin >> f.weaponIndex1;
	fin >> f.weaponIndex2;

	files.push_back(f);

	//add bot
	fin >> f.name1;
	fin >> f.health;
	fin >> f.numhealthPotion;
	fin >> f.weaponIndex1;
	fin >> f.weaponIndex2;

	files.push_back(f);
		//getline(fin, f.name1);
	
	//std::cout << f.name1 << std::endl << f.health << std::endl << f.numhealthPotion << std::endl << f.weaponIndex1 << std::endl << f.weaponIndex2 << std::endl;
	
	//For loop to iterate through the input file and characters
	for (int i = 0; i < files.size(); i++)
	{
		//Add weapons to characters
		Store store;
		Weapon* weapon1 = store.buy(files[i].weaponIndex1);
		Weapon* weapon2 = store.buy(files[i].weaponIndex2);
		

		//Build character
		if (i == 0)
		{
			
			daPlayers[1] = new Player(files[i].name1, files[i].health, files[i].numhealthPotion, weapon1, weapon2);
		}
		else
		{
			daPlayers[2] = new Player(files[i].name1, files[i].health, files[i].numhealthPotion, weapon1, weapon2);
		}
		
	}
	
	
	fin.close();
}