/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include <string>
#include "Player.h"
#include "Swords.h"
#include "Blunt.h"
#include "Shield.h"
#include <iostream>

Player::Player()
{
	this->name = "";
	this->health = 100;
	this->healthCap = 100;
	this->numhealthPotion = 1;

	weapon1 = new Blunt("Fists", 1, 0);
	weapon2 = new Shield("Starter Shield", 0, 10);
}

Player::Player(std::string name, int health, int numhealthPotion, Weapon* weapon1, Weapon* weapon2)
{
	this->name = name;
	this->health = health;
	this->healthCap = health;
	this->numhealthPotion = numhealthPotion;
	this->weapon1 = weapon1;
	this->weapon2 = weapon2;
	this->wI1 = 0;
	this->wI1 = 0;

	
}
void Player::autoChooseWeapons()
{
	//automaticlly get weapons (random)
	Store store;

	int index1 = 0;
	int index2 = rand() % 18 + 1;

	weapon1 = store.buy(index1);
	weapon2 = store.buy(index2);

	wI1 = index1;
	wI2 = index2;
}
void Player::chooseWeapons()
{
	//open store and buy weapons
	Store store;
	std::string response;
	int first;
	int second;

	std::cout << "Choose your Weapons" << std::endl;

	std::cout << "Would you like to browse the Weapons: Y or N" << std::endl;
	std::cin >> response;
	if (response == "Y")
	{
		store.showWeapons();
	}

	
	std::cout << "Enter the Index of your first Weapon" << std::endl;
	std::cin >> first;
	std::cout << "Enter the Index of your second Weapon" << std::endl;
	std::cin >> second;


	weapon1 = store.buy(first);
	weapon2 = store.buy(second);

	wI1 = first;
	wI2 = second;

	std::cout << std::endl;
}



int Player::attack()
{
	//attack

	std::cout << "Choose attack direction: right or left" << std::endl;
	std::cin >> this->attackDirection;

	int damage = weapon1->attack();
	int damage2 = weapon2->attack();

	return (damage + damage2);
}

int Player::autoAttack()
{
	//automaticly attack (random)

	int random = rand() % 3 + 1;
	std::string attDir = "";
	if (random == 1)
	{
		attDir = "right";
	}
	else if (random == 2)
	{
		attDir = "left";
	}


	this->attackDirection = attDir;

	int damage = this->weapon1->attack();
	int damage2 = this->weapon2->attack();

	return (damage + damage2);

}


void Player::block()
{
	//block if shield
	
	if (this->weapon1->getType() == "Shield")
	{
		std::cout << "Choose block direction: right or left" << std::endl;
		std::cin >> blockDirection;
		
	}

	else if (this->weapon2->getType() == "Shield")
	{
		std::cout << "Choose block direction: right or left" << std::endl;
		std::cin >> blockDirection;
		
	}
	else
	{
		blockDirection = "nowhere";
	}
	
}

void Player::autoBlock()
{
	//randomize block
	int random = rand() % 3 + 1;
	std::string blockDir = "";
	if (random == 1)
	{
		blockDir = "right";
	}
	else if (random == 2)
	{
		blockDir = "left";
	}


	if (weapon1->getType() == "Shield")
	{
		this->blockDirection = blockDir;


	}
	else if (weapon2->getType() == "Shield")
	{
		this->blockDirection = blockDir;

	}
	

}

void Player::useHealthPotion()
{
	//use health potion
	if (numhealthPotion > 0)
	{
		this->health += 50;
		if (this->health > this->healthCap)
		{
			this->health = this->healthCap;
		}
		numhealthPotion--;
		std::cout << "Your health is now at: " << health << std::endl;
	}
	else
	{
		std::cout << "You do not have enough health potions" << std::endl;
	}
	
}

//getter and setters

std::string Player::getName()
{
	return name;
}

int Player::getHealth()
{
	return health;
}

void Player::setHealth(int damage)
{
	this->health -= damage;
}


std::string Player::getAttackDirection()
{
	return attackDirection;
}

std::string Player::getBlockDirection()
{
	return blockDirection;
}

int Player::getNumHealthPotion()
{
	return numhealthPotion;
}

int Player::getWI1()
{
	return wI1;
}
int Player::getWI2()
{
	return wI2;
}

bool Player::checkStaff()
{

	std::string nameOfWeapon = weapon1->getType();

	if (nameOfWeapon == "Staff")
	{
		return true;
	}

	std::string nameOfWeapon2 = weapon2->getType();

	if (nameOfWeapon2 == "Staff")
	{
		return true;
	}
	
	return false;
}

bool Player::checkBlunt()
{
	std::string nameOfWeapon = weapon1->getType();

	if (nameOfWeapon == "Blunt")
	{
		return true;
	}

	std::string nameOfWeapon2 = weapon2->getType();

	if (nameOfWeapon2 == "Blunt")
	{
		return true;
	}
	return false;
}
void Player::setName(std::string name)
{
	this->name = name;
}
void Player::setHealthCap(int cap)
{
	healthCap = cap;
}
void Player::setNumHealthPotion(int num)
{
	numhealthPotion = num;
}

void Player::setWeapon1(Weapon* weapon)
{
	weapon1 = weapon;
}
void Player::setWeapon2(Weapon* weapon)
{
	weapon2 = weapon;
}