/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Shield.h"

Shield::Shield(std::string name, int damage, int weight)
{

	setName(name);
	setDamage(damage);
	setWeight(weight);
}

int Shield::attack()
{
	return 0;
	//call bleed proc
}

std::string Shield::getType()
{
	return "Shield";
}