#pragma once

/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Player.h"
#include <ostream>
#include <istream>

using namespace std;


class Arena
{
private:
	Player* daPlayers[3];
public: 
	//bool isYourTurn;
	Arena();

	void fight();
	void turn1();
	void turn2();

	void getWeapons();
	void savePlayerProgress();
	void loadPlayerProgress();

	
};