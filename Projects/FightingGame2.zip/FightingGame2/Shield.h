#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#ifndef SHIELD_H
#define SHIELD_H

#include "Weapon.h"
#include <string>

class Shield : public Weapon
{
private:
	//Just Weapon varialbes
public:
	Shield(std::string, int, int);
	int attack();
	std::string getType();

};



#endif