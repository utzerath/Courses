/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Blunt.h"

Blunt::Blunt(std::string name, int damage, int weight)
{

	setName(name);
	setDamage(damage);
	setWeight(weight);
}

int Blunt::attack()
{
	return damage;

}

std::string Blunt::getType()
{
	return "Blunt";
}