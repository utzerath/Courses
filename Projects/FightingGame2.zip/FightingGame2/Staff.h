#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#ifndef STAFF_H
#define STAFF_H

#include "Weapon.h"
#include <string>

class Staff: public Weapon
{
public:
	Staff();
	Staff(std::string, int, int);
	int attack();

	std::string getType();
	//staff just ignores shields
};

#endif