/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Store.h"
#include <iostream>

Store::Store()
{
	daWeapons.push_back(new Swords("Katana", 20, 5));
	daWeapons.push_back(new Swords("Dagger", 10, 3));
	daWeapons.push_back(new Swords("Curved Sword", 20, 7));
	daWeapons.push_back(new Swords("Striaght Sword", 10, 5));
	daWeapons.push_back(new Swords("Long Sword", 20, 8));

	daWeapons.push_back(new Staff("Jack Magical Staff", 35, 12));
	daWeapons.push_back(new Staff("Lusats Staff", 10, 5));
	daWeapons.push_back(new Staff("North Staff", 20, 7));
	daWeapons.push_back(new Staff("Star Ruin Staff", 21, 4));
	daWeapons.push_back(new Staff("Rock Staff", 9, 6));
	
	daWeapons.push_back(new Blunt("Bat", 20, 4));
	daWeapons.push_back(new Blunt("Morning Star", 25, 14));
	daWeapons.push_back(new Blunt("Police Stick", 10, 4));
	daWeapons.push_back(new Blunt("Guitar", 5, 3));
	daWeapons.push_back(new Blunt("Battle Hammer", 16, 4));

	daWeapons.push_back(new Shield("Brass Shield", 0, 27));
	daWeapons.push_back(new Shield("Dragon Shield", 0, 21));
	daWeapons.push_back(new Shield("Hanks Shield", 0, 15));
	daWeapons.push_back(new Shield("Obsidian Shield", 0, 20));
	daWeapons.push_back(new Shield("Knights Shield", 0, 12));
	
}

Weapon* Store::buy(int index)
{
	return daWeapons[index];
}

void Store::showWeapons()
{
	std::cout << "The list of Weapons are as follows:" << std::endl << std::endl;
	for (int i = 0; i < 20; i++)
	{
		std::cout << daWeapons[i]->getName() << "\nindex = " << i << std::endl;
		std::cout << "Type: " << daWeapons[i]->getType() << "\nDamage: " << daWeapons[i]->getDamage() << "\nWeight: " << daWeapons[i]->getWeight() << std::endl << std::endl;
	}
	std::cout << std::endl;
}