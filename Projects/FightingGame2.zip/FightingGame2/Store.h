#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#ifndef STORE_H
#define STORE_H

#include "Weapon.h"
#include "Swords.h"
#include "Staff.h"
#include "Blunt.h"
#include "Shield.h"
#include <string>
#include <vector>

class Store
{
private:
	std::vector<Weapon*> daWeapons;
	

public:
	Store();
	Weapon* buy(int);
	void showWeapons();
};



#endif