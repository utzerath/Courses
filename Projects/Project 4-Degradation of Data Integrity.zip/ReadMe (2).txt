Specific Problem Solved 
	We are using theoretical approaches that are used to build a system of ODE that models the loss or corruption of data in a digital storage system. This assignment considers real-world factors that affect data degradation.

The mathematical approach to solving it
	First, we are constructing a mathematical model to describe the data flow between three processors. The data flow is both I/O and other data. The mathematical model is expected to be presented as a system of differential equations. The mathematical model is constructed to represent the number of I/O data and other other at a given time in both processors. The eigenvalues of the associated matrix need to be calculated. The goal is for an explanation and quantification of the outcomes.

For the implementation in Code, I used two packages: Numpy and matplotlib. I first used numpy to define a range of x values for the graph. Then, using numpy, I created the equations to graph. I then plotted the equations using matplotlib and displayed the graph.