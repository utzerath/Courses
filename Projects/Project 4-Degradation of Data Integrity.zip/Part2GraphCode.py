import numpy as np
import matplotlib.pyplot as plt

# Define the range of x values
x = np.linspace(-125, 100, 400)

# Compute the corresponding y values for each function
y1 = np.exp(-0.05 * x)
y2 = -np.exp(-0.05 * x)

# Plot the functions
plt.plot(x, y1, label='e^(-0.05x)')
plt.plot(x, y2, label='-e^(-0.05x)')

# Add a legend to explain which line corresponds to which function
plt.legend()

# Add title and labels to the axes
plt.title('Plot of e^(-0.05x) and -e^(-0.05x)')
plt.xlabel('x')
plt.ylabel('y')

# Display the plot
plt.grid(True)
plt.show()
