#Jack Utzerath
#CST-215
#This is my own work

# My Lab Question 6 code
def GCD(x, y):
    rand1 = x
    rand2 = y
    while x != y:
        if x < y:
            y = y-x
        else:
            x = x-y

    #returns GCD
    return x

#Extended Euclideans Algorithm
def EEA(a, b):

    if a == 0:
        return b, 0, 1
    else:

        # tuple = EEA
        d, e, f = EEA(b % a, a)

        #setting x value = y value - (b // a) * the x value
        c = f - (b //a) * e

        # d = GCD
        # c = x value
        # e = y value
        return d, c, e


def Xvalues(count):
    if count == 0:
        return 43
    if count == 1:
        return 491
    if count == 2:
        return 501
    if count == 3:
        return 280
    if count == 4:
        return 958
    if count == 5:
        return 467
    if count == 6:
        return 274
    if count == 7:
        return 154
    if count == 8:
        return 501
    if count == 9:
        return 496
def Yvalues(count):
    if count == 0:
        return 486
    if count == 1:
        return 599
    if count == 2:
        return 896
    if count == 3:
        return 5
    if count == 4:
        return 933
    if count == 5:
        return 652
    if count == 6:
        return 584
    if count == 7:
        return 179
    if count == 8:
        return 562
    if count == 9:
        return 33


if __name__ == '__main__':

    count = 0

    for x in range (0, 10):

        if GCD(Xvalues(count), Yvalues(count)) == 1:
            gcd, xVal, yVal = EEA(Xvalues(count), Yvalues(count))
            print("\t", Xvalues(count), "\t", Yvalues(count), "\t", gcd, "\t", Xvalues(count),"*(", xVal, ")+", Yvalues(count), "*(", yVal, ") = 1")
        else:
            print("\t", Xvalues(count), "\t", Yvalues(count), "\t", GCD(Xvalues(count), Yvalues(count)))

        count += 1
