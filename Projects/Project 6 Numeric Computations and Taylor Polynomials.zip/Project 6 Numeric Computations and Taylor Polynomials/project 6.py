#Jack Utzerath
#Principles of modeling and simulation
#Project 6

#########
import numpy as np
import matplotlib.pyplot as plt

#Part 1 A) 

#define taylor polynomial
def taylor_polynomial(x):
    return 1 - x - (1/3)*x**3 - (1/12)*x**4

#Print out y at x = 3.5
x_3_5 = 3.5
y_at_3_5 = taylor_polynomial(x_3_5)
print(f"The value of the Taylor polynomial at x = {x_3_5} is y = {y_at_3_5}")


# Define a range for x to visualize the polynomial
x_values = np.linspace(-2, 6, 400)

# Evaluate the Taylor polynomial at each point in x
y_values = taylor_polynomial(x_values)

# Visualize the Taylor polynomial
plt.figure(figsize=(10, 6))
plt.plot(x_values, y_values, label='Taylor Polynomial')

# Mark the point of interest at x = 3.5
y_at_3_5 = taylor_polynomial(3.5)
plt.scatter([3.5], [y_at_3_5], color='red', zorder=5, label='Point at x=3.5')

# Set the labels and title
plt.xlabel('x')
plt.ylabel('y')
plt.title('Visualization of the Taylor Polynomial and its Convergence')
plt.legend()
plt.grid(True)

# Show the plot
plt.show()

#----------------------------------------------------------------------------------------------
#Part 1 B)

#define taylor polynomial
def taylor_polynomial(x):
    return ((-11*x**2)/2 +34*x -93/2)


# Define a range for x near the point of expansion x0 = 3
x = np.linspace(2, 4, 400)

# Evaluate the Taylor polynomial at each point in x
y_taylor = taylor_polynomial(x)

# Visualize the Taylor polynomial
plt.figure(figsize=(10, 6))
plt.plot(x, y_taylor, label='Second-order Taylor Polynomial')

# Assuming the original function is smooth and follows the pattern given by the initial conditions
plt.plot(x, y_taylor, label='Approximated Original Function', linestyle='--')

# Mark the point of expansion with a red dot
plt.scatter([3], [6], color='red', label='3')

# Set the labels and title
plt.xlabel('x')
plt.ylabel('y')
plt.title('Convergence of the Second-order Taylor Polynomial')
plt.legend()
plt.grid(True)

# Show the plot
plt.show()

#-----------------------------------------------------------------------------------
#Part 2
import numpy as np
from scipy.integrate import solve_ivp

# Define the differential equation as a function
def ode_system(t, y):
    y0, y1 = y
    dydt = [y1, (t - y0) / (t**2 + 4)]
    return dydt

# Initial conditions (guess y(0) = 0, y'(0) = 0)
y_init = [0, 0]

# Time span for the solution
t_span = [0, 1]  # We can solve for x in the range from 0 to 1, for example

# Time points at which to store the numerical solution
t_eval = np.linspace(t_span[0], t_span[1], 100)

# Solve the ODE numerically
solution = solve_ivp(ode_system, t_span, y_init, t_eval=t_eval, method='RK45')

# Print the numerical solution for y(x)
print("Numerical solution for y(x) at 100:")
print(solution.y[0])


#-------------------------------------------------------------------------
#Part 3

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint

# Define the system of differential equations
def system(y, t, k1, k2, k3):
    P, M = y
    dtdP = k1*P - k2*P*M
    dtdM = k3*P
    return [dtdP, dtdM]

# Initial conditions
P0 = 1.0  # initial processing power
M0 = 1.0  # initial memory capacity
y0 = [P0, M0]

# Time vector
t = np.linspace(0, 10, 200)  # simulate for 10 units of time with 200 points

# Constants
k1 = 0.2  # rate of processing power increase
k2 = 0.1  # impact of memory on processing power
k3 = 0.05 # rate at which memory capacity changes due to processing power

# Solve the DEs
solution = odeint(system, y0, t, args=(k1, k2, k3))

# Plot results
plt.figure(figsize=(12, 5))

# Processing Power plot
plt.subplot(1, 2, 1)
plt.plot(t, solution[:, 0], label='Processing Power (P)')
plt.title('Processing Power over Time')
plt.xlabel('Time')
plt.ylabel('Processing Power (P)')
plt.legend()

# Memory Capacity plot
plt.subplot(1, 2, 2)
plt.plot(t, solution[:, 1], label='Memory Capacity (M)')
plt.title('Memory Capacity over Time')
plt.xlabel('Time')
plt.ylabel('Memory Capacity (M)')
plt.legend()

plt.tight_layout()
plt.show()

