ReadMe

Group: Jack Utzerath and Hunter Jenkins

We are ambitious computer science student each from the same high school. We excel in problem solving and work relentlessly. 

The document "Familiarity With Linux" by Jack Utzerath & Hunter Jenkins from the College of Technology at Grand Canyon University, prepared for CST-315: Operating Systems Lab under Citro Ricardo, dated 1/19/24, provides insights into various Linux commands and their functionalities. It includes detailed explanations of commands like 'cd' (for changing directories), 'mkdir' (for creating directories), 'ls' (for listing directory contents), 'pwd' (for displaying the current directory), and 'kill' (for terminating processes). Additionally, the document contains screenshots demonstrating the use of these commands, as well as examples of installing Ubuntu, creating simple print functions, and handling directories and files in Linux.