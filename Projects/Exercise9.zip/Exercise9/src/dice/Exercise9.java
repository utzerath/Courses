/*
 * Jack Utzerath
 * CST-105 (9am)
 * Assignment
 * Dec 11, 2021
 * This is my work
 */

package dice;

public class Exercise9 {

	public static void main(String[] args) {
		// Driver Method

		//Ititialize Variable
		int numberOfRolls = 100000;
		int threeOfAKind = 0, fourOfAKind = 0, fiveOfAKind = 0;

		//For loop to generate multiple rolls
		for (int j = 0; j < numberOfRolls; j++) {
			
			int[] dice = createDice(5);
			//Type of roll to keep track of important info
			threeOfAKind += typeOfRoll(dice, 3);
			fourOfAKind += typeOfRoll(dice, 4);
			fiveOfAKind += typeOfRoll(dice, 5);

		}

		//Final Print Command
		System.out.printf("In %,d rolls, you rolled 3 of a kind %,d times, 4 of a kind %,d times, "
				+ "and 5 of a kind %,d times.", numberOfRolls, threeOfAKind, fourOfAKind, fiveOfAKind);

	}

//------------------------------------------------------------

	//Creates Dice
	public static int[] createDice(int amountOfDice) {
		
		//create object of the class
		Dice die = new Dice();

		//Initialize Variables
		int[] dice = new int[amountOfDice];

		//For loop to place random integer for each dice
		for (int j = 0; j < dice.length; j++) {
			int currentDie = die.rollWeightedDice();

			dice[j] = currentDie;

			/*
			 System.out.println(dice[j]);
			 */
			
		}

		//return array
		return dice;
	}

//------------------------------------------------------------

	public static int typeOfRoll(int[] dice, int index) {

		int count1 = 0;
				
		int threeOfAKind = 0, fourOfAKind = 0, fiveOfAKind = 0;

		//Created Nexted four loop to keep track of varaiables 
		for (int i = 1; i <= 6; i++) 
		{
			count1 = 0;

			for (int j = 0; j < dice.length; j++) 
			{

				if (dice[j] == i)				
				{
					count1++;
					
					if (count1 == 3 && count1 != 4 && count1 != 5)
					{
						threeOfAKind++;
					}
					if (count1 == 4 && count1 != 5)
					{
						fourOfAKind++;
					}
					if (count1 == 5)
					{
						fiveOfAKind++;
					}
				}
				

			}

		}
		
		//Switch statment to return varaiable 
		int number = 0;

		switch (index) 
		{
		case 3:
			number = threeOfAKind;
			break;
		case 4:
			number = fourOfAKind;
			break;
		case 5:
			number = fiveOfAKind;
			break;

		}
		return number;
	}
}
