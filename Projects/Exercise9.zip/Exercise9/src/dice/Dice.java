/*
 * Jack Utzerath
 * CST-105 (9am)
 * Exercise 9
 * Dec 11, 2021
 * This is my work
 */


package dice;



public class Dice {
	
	private int value;
	
//Constructor
	public Dice()
	{
		this.value = 0;
	}
	
	public Dice(int value)
	{
		this.value = value;
	}

//Getter and Setter
	public int getValue() {
		return value;
	}

	
	public void setValue(int value) {
		this.value = value;
	}
	
//--------------------------------------------------------------------
	
	//creates normal dice roll
	public int rollDice()
	{
		int max = 7, min = 1;
		
		int topOfTheDie = (int)(Math.random() * (max - min) + min);
		
		this.setValue(topOfTheDie);
		
		return topOfTheDie;
		
	}
	
//---------------------------------------------------------------------
	
	//creates weighted dice roll
	
	public int rollWeightedDice()
	{
		int [] diceArray;
		
		diceArray = new int[100];
		
		for (int j = 0; j < 100; j++)
		{
			if (j <= 40)
			{
				diceArray[j] = 1;
			}
			if (j > 40 && j <= 55 )
			{
				diceArray[j] = 2;
			}
			if (j > 55 && j <= 70 )
			{
				diceArray[j] = 3;
			}
			if (j > 70 && j <= 80 )
			{
				diceArray[j] = 4;
			}
			if (j > 80 && j <= 90 )
			{
				diceArray[j] = 5;
			}
			if (j > 90)
			{
				diceArray[j] = 6;
			}
			
		}
		
		int max = 100, min = 1;
		
		int topOfTheDie = (int)(Math.random() * (max - min) + min);
		
		return diceArray[topOfTheDie];
		
	}
	
	
	

}
