/*Jack Utzerath
* Lucky 7
* CST-2
*/

#include <iostream>
#include <string>
using namespace std;
	

void f1();
void f2();
void f3();
void f4();
void f5();
void f6();
void f7();


int main()
{
	f1();
	f2();
	return 0;
}


//Write a program that read in 5 intergers
//Prints the largest and the smallest of the group
void f1() {
	int currNum, small, large;
	
	cout << "Enter 5 ints: ";
	cin >> currNum;
	//first entry is small and large
	small = large = currNum;

	//Loop
	for (int i = 1; i <= 4; i++) 
	{
		cin >> currNum;
		if (currNum < small)
			small = currNum;
		else if (currNum > large)
			large = currNum;

	}
	cout << "largest = " << large << " smallest = " << small << endl;


}
//Write a program that calculate and prints the sum of the first 50
//Positive integers that are multiples of 7

void f2() {

	int sum = 0;

	for (int i = 0; i <= 50; i++) {
		sum += i * 7;
	}
	cout << "sum = " << sum << endl;
}
void f3() {

}
void f4() {

}
void f5() {

	
}
void f6() {

}
void f7() {

}