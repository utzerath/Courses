/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Arena.h"
#include "Player.h"
#include <iostream>

Arena::Arena()
{
	daPlayers[0] = new Player("Jutz", 100, 2);
	daPlayers[1] = new Player("Hunter", 100, 0);
}

void Arena::fight()
{
	bool alive = true;
	while (alive)
	{
		//add direction to attack and block

		daPlayers[0]->attack();
		daPlayers[1]->block();

		std::cout << daPlayers[1]->getName() << " has " << daPlayers[1]->getHealth() << " health" << std::endl;

		if (daPlayers[1]->getHealth() <= 0)
		{
			alive = false;
		}

		daPlayers[1]->attack();
		daPlayers[0]->block();
		
		std::cout << daPlayers[0]->getName() << " has " << daPlayers[0]->getHealth() << " health" << std::endl;
		if (daPlayers[0]->getHealth() <= 0)
		{
			alive = false;
		}
		

	}
}

