/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include <string>
#include "Player.h"
#include "Swords.h"

Player::Player()
{

}

Player::Player(std::string name, int health, int numhealthPotion)
{
	this->name = name;
	this->health = health;
	this->healthCap = health;
	this->numhealthPotion = numhealthPotion;
	
	weapons[0] = new Swords("katana", 20, 5);
	weapons[1] = new Swords("katana", 20, 5);
}

void Player::attack()
{
	int damage = weapons[0]->attack();

	this->health -= damage;
}

void Player::block()
{
	
}

void Player::useHealthPotion()
{
	this->health + 50;
	if (this->health > this->healthCap)
	{
		this->health = this->healthCap;
	}
}

std::string Player::getName()
{
	return name;
}

int Player::getHealth()
{
	return health;
}