#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#ifndef SWORDS_H
#define SWORDS_H

#include "Weapon.h"
#include <string>

class Swords: public Weapon
{
private:
	int bleedBuildUp;
	int bleedDamage;
public:
	Swords();
	Swords(std::string, int, int);
	int attack();
	int bleedProc();
};



#endif