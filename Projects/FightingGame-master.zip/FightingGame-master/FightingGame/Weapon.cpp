/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work :)
*/

#include "Weapon.h"
#include <string>
#include <vector>

Weapon::Weapon()
{

}

Weapon::Weapon(std::string name, int damage, int weight)
{
	this->name = name;
	this->damage = damage;
	this->weight = weight;
	numWeapons++;
}
int Weapon::attack()
{
	return damage;
}

void Weapon::setName(std::string name)
{
	this->name = name;
}

void Weapon::setDamage(int damage)
{
	this->damage = damage;
}
void Weapon::setWeight(int weight)
{
	this->weight = weight;
}
