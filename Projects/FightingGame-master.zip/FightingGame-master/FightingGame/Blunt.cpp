/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Blunt.h"

Blunt::Blunt(std::string name, int damage, int weight)
{

	setName(name);
	setDamage(damage);
	setWeight(weight);
}

int Blunt::attack()
{
	return damage;
	//call bleed proc
}
bool Blunt::stagger()
{
	this->staggerBuildUp + 50;


	if (staggerBuildUp >= 100)
	{
		numStagger++;

		if (numStagger == 2)
		{
			return false;
		}

		return true;

	}
	return false;
}
