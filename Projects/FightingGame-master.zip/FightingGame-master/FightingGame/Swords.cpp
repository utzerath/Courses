/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Swords.h"

Swords::Swords(std::string name, int damage, int weight)
{

	setName(name);
	setDamage(damage);
	setWeight(weight);
}

int Swords::attack()
{
	return damage + bleedProc();
	//call bleed proc
}
int Swords::bleedProc()
{
	this->bleedBuildUp += 50;

	if (bleedBuildUp > 100)
	{
		this-> bleedDamage + 3;
		return bleedDamage;
	}
	return 0;
}

