#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include <string>
#include "Weapon.h"

class Player
{
private:
	std::string name;
	Weapon weapon;
	int health;
	int healthCap;
	int numhealthPotion;
	int attackDirection;
	int blockDirection;

	Weapon* weapons[1];



public:

	Player();
	Player(std::string name, int health, int healthPotion);
	void attack();
	void block();
	void useHealthPotion();
	std::string getName();
	int getHealth();
	
	//add weapon boy

};