#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#ifndef BLUNT_H
#define BLUNT_H

#include "Weapon.h"
#include <string>

class Blunt: public Weapon
{
private:
	int staggerBuildUp = 0;
	int numStagger = 0;

public:
	Blunt();
	Blunt(std::string, int, int);
	int attack();
	bool stagger();
};



#endif