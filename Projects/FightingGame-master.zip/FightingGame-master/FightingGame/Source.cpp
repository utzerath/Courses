/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Arena.h"

int main()
{
	Arena a;
	a.fight();
	return 0;
}