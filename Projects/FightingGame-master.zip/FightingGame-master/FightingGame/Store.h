#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#ifndef STORE_H
#define STORE_H

#include "Weapon.h"
#include <string>

class Store
{
private:
	Weapon* daWeapons;
	int money;

public:
	void buy();
};



#endif