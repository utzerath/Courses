#pragma once

/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/

#include "Player.h"


class Arena
{
public: 
	bool isYourTurn;
	Arena();
	Player* daPlayers[1];
	void fight();
};