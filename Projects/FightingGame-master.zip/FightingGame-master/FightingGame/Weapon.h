#pragma once
/*
* Jack Utzerath
* Cst-210
* Fighting Game
* This is my own work : )
*/
#ifndef WEAPON_H
#define WEAPON_H

#include <string>
#include <vector>

class Weapon
{
protected:
	std::string name;
	int damage;
	int weight;
	int numWeapons = 0;
	std::vector <Weapon> daWeapons;

public:
	Weapon();
	Weapon(std::string, int, int);
	virtual int attack();

	void setName(std::string);
	void setDamage(int);
	void setWeight(int);
	

	

};


#endif 