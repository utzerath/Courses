/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/
#pragma once

#ifndef CHICKen_H
#define CHICKEN_H

#include <string>
#include "Animal.h"

class Chicken : public Animal
{

private:
	void gainWeight();

public:
	Chicken();
	Chicken(std::string, double, double);
	void eat();

};

#endif