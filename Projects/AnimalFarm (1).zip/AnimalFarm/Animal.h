/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/
#pragma once

#ifndef Animal_H
#define Animal_H

#include <string>
#include <iostream>



class Animal 
{

protected:
	std::string name;
	double weight;
	double height;

private:
	void gainWeight();

public:
	Animal();
	Animal(std::string, double, double);
	std::string getName()const;
	double getWeight() const;
	double getHeight() const;
	void setWeight(double);
	void setHeight(double);
	void setName(std::string);
	virtual void eat();

};

#endif
