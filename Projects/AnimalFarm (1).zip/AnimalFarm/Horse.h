/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/
#pragma once

#ifndef HORSE_H
#define HORSE_H

#include <string>
#include "Animal.h"

class Horse : public Animal
{

private:
	void gainWeight();

public:
	Horse();
	Horse(std::string, double, double);
	void eat();
};

#endif