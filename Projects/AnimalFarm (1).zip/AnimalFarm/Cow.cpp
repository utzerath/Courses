/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/


#include "Cow.h"


Cow::Cow()
{
	setName("Nameless Cow");
	setHeight(2);
	setWeight(2);
}

//Constructor
Cow::Cow(std::string name, double height, double weight)
{
	setName(name);
	setHeight(height);
	setWeight(weight);
}

void Cow::gainWeight()
{
	//add to the weight
	weight += 9;
	std::cout << name << " gained 9 pounds" << std::endl;
	std::cout << name << " now weighs " << weight << " pounds!" << std::endl<< std::endl;


}

void Cow::eat()
{

	//name print statement
	std::cout << getName() << " is eating some grass." << std::endl;
	gainWeight();

}
