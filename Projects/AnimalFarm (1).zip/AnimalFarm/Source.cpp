/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/

#include "Barn.h"


int main() {

	//Feed statements in barn class
	Barn b;
	b.feedCows();
	b.feedChickens();
	b.feedHorse();


	return 0;
};