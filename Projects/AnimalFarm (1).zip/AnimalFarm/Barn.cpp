/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/

#include <random>
#include "Barn.h"
#include "Chicken.h"
#include <vector>

Barn::Barn()
{
	//Adding animals to vectors
	jacks_coop.push_back(Chicken("Sally", 8, 27));
	jacks_coop.push_back(Chicken("Steve", 5.5, 17));
	jacks_coop.push_back(Chicken("Alfred", 4, 10));
	jacks_coop.push_back(Chicken("Dequavious", 5.7, 22));
	jacks_coop.push_back(Chicken("Lainey", 6, 25));


	jacks_stall.push_back(Horse("Hunter", 1800, 75));
	jacks_stall.push_back(Horse("Swens", 979, 59));


	jacks_pen.push_back(Cow("Hayden", 1700, 58));
	jacks_pen.push_back(Cow("Ainsley", 1559, 52));
	jacks_pen.push_back(Cow("Mason", 843, 39));
	jacks_pen.push_back(Cow("Jayden", 1308, 61));

}
void Barn::feedChickens()
{
	//statement to feed the chickens
	std::cout << "Feeding the Chickens" << std::endl;

	//For loop to loop through coop vector
	for (int i = 0; i < jacks_coop.size(); i++)
	{
		jacks_coop[i].eat();
	}

	std::cout << std::endl;
	
}
void Barn::feedCows()
{
	//statement to feed the cows
	std::cout << "Feeding the Cows" << std::endl;

	//For loop to loop through pen vector
	for (int i = 0; i < jacks_pen.size(); i++)
	{
		jacks_pen[i].eat();
	}
	std::cout << std::endl;
}
void Barn::feedHorse()
{
	//statement to feed the Horses
	std::cout << "Feeding the Horses" << std::endl;

	//For loop to loop through stall vector
	for (int i = 0; i < jacks_stall.size(); i++)
	{
		jacks_stall[i].eat();
	}
	std::cout << std::endl;
}

void Barn::eat()
{
	//Run through all eat methods
	std::cout << "Lunch Time!!! All of the animals are eating.";
	feedChickens();
	feedCows();
	feedHorse();
}