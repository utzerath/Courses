/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/

#include "Horse.h"


Horse::Horse() 
{
	setName("Nameless Horse");
	setHeight(2);
	setWeight(2);
}
Horse::Horse(std::string name, double height, double weight) 
{
	setName(name);
	setHeight(height);
	setWeight(weight);
}

void Horse::gainWeight()
{
	//add to the weight
	weight += 7;
	//weight statements
	std::cout << name << " gained 7 pounds" << std::endl;
	std::cout << name << " now weighs " << weight << " pounds!" << std::endl << std::endl;


}

void Horse::eat()
{
	//name statements
	std::cout << getName() << " is eating some hay.";
	//gain weight method
	gainWeight();

}

