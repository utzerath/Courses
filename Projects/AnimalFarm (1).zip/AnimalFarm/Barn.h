/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/

#pragma once
#ifndef BARN_H
#define BARN_H

#include <string>
#include<vector>
#include "Cow.h"
#include "Chicken.h"
#include "Horse.h"


class Barn
{

private:
	std::vector<Chicken> jacks_coop;
	std::vector<Horse> jacks_stall;
	std::vector<Cow> jacks_pen;

public:
	Barn();
	void feedChickens();
	void feedCows();
	void feedHorse();
	void eat();
};

#endif
