/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/

#include "Animal.h"
#include <iostream>

Animal::Animal() 
{

}
//Constructor
Animal::Animal(std::string name, double height, double weight)
{
	this->name = name;
	this->height = height;
	this->weight = weight;
}
//Getters and setters
std::string Animal::getName()const
{
	return name;
}

double Animal::getWeight()const
{
	return weight;
}

double Animal::getHeight()const
{
	return height;
}
void Animal::setWeight(double weight)
{
	this->weight = weight;
}
void Animal::setHeight(double height)
{
	this->height = height;
}
void Animal::setName(std::string name)
{
	this->name = name;
}

void Animal::eat()
{
	//Basic eat statement
	std::cout << getName() << " is Eating \n";
}
void Animal::gainWeight()
{
	//Basic eat statement
}