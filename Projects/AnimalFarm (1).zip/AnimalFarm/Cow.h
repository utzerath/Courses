/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/
#pragma once

#ifndef COW_H
#define COW_H

#include <string>
#include "Animal.h"

class Cow : public Animal
{

private:
	void gainWeight();

public: 
	Cow();
	Cow(std::string, double, double);
	void eat();
};

#endif