/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/

#pragma once
#ifndef BARN_H
#define BARN_H

#include <string>
#include<vector>
#include "Cow.h"
#include "Chicken.h"
#include "Horse.h"


class Barn
{

private:
	// Pointers are required for poloymorphic variables
	Animal* daAnimals[15];
	int numAnimals;

public:
	Barn();
	void outToPasture(int);
	void showAll();
	void feedAll();
	void eat();
	std::string randName(int);
	~Barn();
};

#endif