/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/

#include "Chicken.h"
#include <iostream>


Chicken::Chicken()
{
	setName("Nameless Chicken");
	setHeight(2);
	setWeight(2);

}

//Constructor
Chicken::Chicken(std::string name, double weight, double height)
{
	setName(name);
	setHeight(height);
	setWeight(weight);
}

void Chicken::gainWeight()
{
	//Add to the weight
	weight += .25;

	//Print Statments
	std::cout << name << " gained .25 pounds" << std::endl;
	std::cout << name << " now weighs " << weight << " pounds!" << std::endl << std::endl;

}


void Chicken::eat()
{
	//Get name in statement
	std::cout << name << " is eating some corn." << std::endl;
	gainWeight();

}

void Chicken::speak()
{
	//name statements
	std::cout << getName() << " says Cluck";


}
int Chicken::getTopWeight()
{
	return 12;
}
std::string Chicken::getType()
{
	return "Chicken";
}