/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/


#include "Cow.h"


Cow::Cow()
{
	setName("Nameless Cow");
	setHeight(2);
	setWeight(2);
}

//Constructor
Cow::Cow(std::string name, double weight, double height)
{
	setName(name);
	setHeight(height);
	setWeight(weight);
}

void Cow::gainWeight()
{
	//add to the weight
	weight += 9;
	std::cout << name << " gained 9 pounds" << std::endl;
	std::cout << name << " now weighs " << weight << " pounds!" << std::endl << std::endl;


}

void Cow::eat()
{

	//name print statement
	std::cout << getName() << " is eating some grass." << std::endl;
	gainWeight();

}

void Cow::speak()
{
	//name statements
	std::cout << getName() << " says Moo" << std::endl;


}

int Cow::getTopWeight()
{
	return 1500;
}

std::string Cow::getType()
{
	return "Cow";
}