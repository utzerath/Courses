/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/


//  here
//     https://www.loom.com/share/e31f764e27c54d2a8802e4663290aa74
//** This is the zoom link **


#include "Barn.h"


int main() {

	//Feed statements in barn class
	Barn b;
	b.showAll();
	b.feedAll();
	b.showAll();
	


	return 0;
};