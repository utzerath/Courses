/*
* Jack Utzerath
* CST-210
* 2/24/2022
* Animal Farm
* This is my own work
*/

#include <random>
#include "Barn.h"
#include "Chicken.h"
#include <vector>
#include <string>

Barn::Barn()
{
	//adding animals to array 
	numAnimals = 0;
	daAnimals[numAnimals++] = new Chicken("Sally", 9.5, 4.5);
	daAnimals[numAnimals++] = new Chicken("Alfred", 10, 4);
	daAnimals[numAnimals++] = new Chicken("Grace", 9,4.9);
	daAnimals[numAnimals++] = new Chicken("Lainey", 25,6);
	daAnimals[numAnimals++] = new Chicken("Alfred", 10.5, 10);
	daAnimals[numAnimals++] = new Chicken("Julia", 17, 5.7);
	daAnimals[numAnimals++] = new Chicken("Blanket", 5, 6);
	daAnimals[numAnimals++] = new Chicken("Henry", 11, 6);
	daAnimals[numAnimals++] = new Chicken("Seth",  22, 5.7);


	daAnimals[numAnimals++] = new Horse("Hunter", 1800, 75);
	daAnimals[numAnimals++] = new Horse("Swens", 979, 59);

	daAnimals[numAnimals++] = new Cow("Hayden", 1900, 58);
	daAnimals[numAnimals++] = new Cow("Ainsley", 1159, 52);
	daAnimals[numAnimals++] = new Cow("Mason", 843, 39);
	daAnimals[numAnimals++] = new Cow("Bessy", 1720, 59);



}
void Barn::showAll()
{
	//For loop iterating through array
	std::cout << "BARN CONTAINS" << std::endl << std::endl;
	for (int i = 0; i < numAnimals; i++)
	{
		std::string type = daAnimals[i]->getType();
		if (type == "Cow")
		{
			std::cout << daAnimals[i]->getName() << " the cow" << std::endl;
		}
		if (type == "Horse")
		{
			std::cout << daAnimals[i]->getName() << " the horse" << std::endl;
		}
		if (type == "Chicken")
		{
			std::cout << daAnimals[i]->getName() << " the chicken" << std::endl;
		}
		

	}
	std::cout <<  std::endl;
}
void Barn::feedAll()
{

	//statement to feed the Animals
	std::cout << "Feeding the Animals" << std::endl << std::endl;

	//For loop to loop through coop vector
	for (int i = 0; i < numAnimals; i++)
	{
		daAnimals[i]->eat();
		if (daAnimals[i]->getTopWeight() < daAnimals[i]->getWeight())
		{
			outToPasture(i);
		}
		

	}

	std::cout << std::endl;
}

void Barn::outToPasture(int i)
{
	//Get type and name before delete
	std::string type = daAnimals[i]->getType();
	std::string previousName = daAnimals[i]->getName();
	delete daAnimals[i];

	
	//If statement for different animals 
	if (type == "Cow")
	{
		daAnimals[i] = new Cow(randName(i), 1100, 53);
		std::cout << previousName << " the cow has exceeded the top weightt of 1500" << std::endl;
		std::cout << daAnimals[i]->getName() << " the cow replaced " << previousName << std::endl;
	}
	if (type == "Chicken")
	{
		daAnimals[i] = new Chicken(randName(i), 9, 9);
		std::cout << previousName << " the chicken has exceeded the top weight of 12" << std::endl;
		std::cout << daAnimals[i]->getName() << " the chicken replaced " << previousName << std::endl;
	}
	if (type == "Horse")
	{
		daAnimals[i] = new Horse(randName(i), 1501, 65);
		std::cout << previousName << " the horse has exceeded the top weight of 1500" << std::endl;
		std::cout << daAnimals[i]->getName() << " the horse replaced " << previousName << std::endl;
	}
	std::cout << std::endl;
}


void Barn::eat()
{
	//Run through all eat methods
	std::cout << "Lunch Time!!! All of the animals are eating.";
	feedAll();
}

std::string Barn::randName(int i)
{
	//get rand int and 12
	std::string newName = "";
	switch (i)
	{
	case 0: newName = "Lydia";
		break;
	case 1: newName = "Alison";
		break;
	case 2: newName = "Jerry";
		break;
	case 3: newName = "John";
		break;
	case 4: newName = "Jayden";
		break;
	case 5: newName = "David";
		break;
	case 6: newName = "Tyler";
		break;
	case 7: newName = "Nora";
		break;
	case 8: newName = "Delainey";
		break;
	case 9: newName = "Katherine";
		break;
	case 10: newName = "Havocs";
		break;
	case 11: newName = "Thunder";
		break;
	case 12: newName = "Avery";
		break;
	case 13: newName = "Mia";
		break;
	case 14: newName = "Glasses";
		break;
	case 15: newName = "Buddy";
		break;
	default: newName = "NoName";
	}
	return newName;
}

Barn::~Barn()
{
	//For loop deleteing animals at I
	for (int i = 0; i < numAnimals; i++)
	{
		delete daAnimals[i];
	}
}